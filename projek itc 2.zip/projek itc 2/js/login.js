$(document).ready(function () {
  $("#loginButton").click(function () {
    $("#loginModal").modal("show");
  });

  // Initialize tooltips
  $('[data-toggle="tooltip"]').tooltip();
});